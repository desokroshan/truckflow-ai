#!/bin/bash
echo "🚀 Deploying TruckFlow production server..."

# Stop existing app
pm2 stop truckflow 2>/dev/null || true
pm2 delete truckflow 2>/dev/null || true

# Install ALL dependencies (not just production)
echo "Installing dependencies..."
npm install

# Check if production server exists
if [ ! -f "dist/production-server.js" ]; then
    echo "❌ Production server not found!"
    exit 1
fi

# Create logs directory
mkdir -p logs

# Start production server with ecosystem file
echo "Starting TruckFlow server with ecosystem configuration..."
pm2 start ecosystem.config.js

# Save PM2 configuration
pm2 startup
pm2 save

echo "✅ TruckFlow deployed successfully!"
echo "🌐 Access at: http://$(curl -s ifconfig.me):5000"

# Show status
pm2 status

echo ""
echo "📋 Quick commands:"
echo "  Check logs: pm2 logs truckflow"
echo "  Restart:    pm2 restart truckflow"
echo "  Stop:       pm2 stop truckflow"